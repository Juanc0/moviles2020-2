package co.edu.unal.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.lang.reflect.Array;

/**
 * Skeleton of an Android Things activity.
 * <p>
 * Android Things peripheral APIs are accessible through the PeripheralManager
 * For example, the snippet below will open a GPIO pin and set it to HIGH:
 * <p>
 * PeripheralManager manager = PeripheralManager.getInstance();
 * try {
 * Gpio gpio = manager.openGpio("BCM6");
 * gpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * gpio.setValue(true);
 * } catch (IOException e) {
 * Log.e(TAG, "Unable to access GPIO");
 * }
 * <p>
 * You can find additional examples on GitHub: https://github.com/androidthings
 */
public class AndroidTicTacToeActivity extends AppCompatActivity {


    // Represents the internal state of the game
    private TicTacToeGame mGame;

    // Various text displayed
    private TextView mInfoTextView;
    private TextView mHumanCount;
    private TextView mTieCount;
    private TextView mAndroidCount;


    private boolean mGameOver;

    private boolean humanFirst;
    private boolean humanTurn;
    private int humanWinsCount;
    private int tiesCount;
    private int androidWinsCount;

    //static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;

    private BoardView mBoardView;
    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;

    private boolean mSoundOn = true;
    private SharedPreferences mPrefs;

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.drop_single);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.water_drop);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_tac_toe);

        // Restore the scores from the persistent preference data source
        mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        mSoundOn = mPrefs.getBoolean("sound", true);
        String difficultyLevel = mPrefs.getString("difficulty_level",
                getResources().getString(R.string.difficulty_harder));


        mGame = new TicTacToeGame();
        if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
        else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
        else
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);


        mInfoTextView = (TextView) findViewById(R.id.information);
        mHumanCount = (TextView) findViewById(R.id.humanCount);
        mTieCount = (TextView) findViewById(R.id.tieCount);
        mAndroidCount = (TextView) findViewById(R.id.androidCount);

        humanFirst = true;
        humanTurn = true;
        humanWinsCount = 0;
        tiesCount = 0;
        androidWinsCount = 0;

        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setmGame(mGame);
        // Listen for touches on the board
        mBoardView.setOnTouchListener(mTouchListener);


        startNewGame();

    }


    // Set up the game board.
    private void startNewGame() {
        mGameOver = false;
        mGame.clearBoard();


        // Human goes first

        if(humanFirst)
            mInfoTextView.setText(R.string.first_human);
        else {
            humanTurn = false;
            mInfoTextView.setText(R.string.first_computer);
            computerTurn();
        }
        mBoardView.invalidate();
    }

    private int computerTurn(){
        humanTurn = false;
        final int move = mGame.getComputerMove();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                setMove(move, TicTacToeGame.COMPUTER_PLAYER);
                humanTurn = true;
                mInfoTextView.setText(R.string.turn_human);
            }
        }, 2000);

        return mGame.checkForWinner();
    }

    private boolean setMove(int location, char player) {
        if (mGame.setMove(location, player)) {
            mBoardView.invalidate();   // Redraw the board
            if(mSoundOn)
                if(player == TicTacToeGame.HUMAN_PLAYER)
                    mHumanMediaPlayer.start();    // Play the sound effect
                else
                    mComputerMediaPlayer.start();    // Play the sound effect
            return true;
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        //menu.add("New Game");
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //startNewGame();

        switch (item.getItemId()) {
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.settings:
                //createdDialog(DIALOG_DIFFICULTY_ID).show();
                //showDialog(DIALOG_DIFFICULTY_ID);

                startActivityForResult(new Intent(this, Settings.class), 0);
                return true;
            case R.id.quit:
                //createdDialog(DIALOG_QUIT_ID).show();
                showDialog(DIALOG_QUIT_ID);
                return true;
        }
        return false;

    }
    //protected Dialog createdDialog(int id) {
        // Your code
    //}

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id) {
            /*case DIALOG_DIFFICULTY_ID:

                builder.setTitle(R.string.difficulty_choose);

                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_harder),
                        getResources().getString(R.string.difficulty_expert)};

                // TODO: Set selected, an integer (0 to n-1), for the Difficulty dialog.
                // selected is the radio button that should be selected.
                int selected = mGame.getDifficultyLevel().getDifficultyNum();

                builder.setSingleChoiceItems(levels, selected,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                dialog.dismiss();   // Close dialog

                                // TODO: Set the diff level of mGame based on which item was selected.


                                // Display the selected difficulty level
                                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.values()[item]);
                                Toast.makeText(getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();

                break;*/
            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog

                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AndroidTicTacToeActivity.this.finish();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();

                break;
        }

        return dialog;
    }

    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;

            if (!mGameOver && humanTurn && setMove(pos, TicTacToeGame.HUMAN_PLAYER))	{

                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();
                if (winner == 0) {
                    mInfoTextView.setText(R.string.turn_computer);
                    winner = computerTurn();
                }

                switch (winner){
                    case 0:
                        break;
                    case 1:
                        mInfoTextView.setText(R.string.result_tie);
                        mGameOver = true;
                        tiesCount++;
                        mTieCount.setText(String.valueOf(tiesCount));
                        humanFirst = !humanFirst;
                        break;
                    case 2:
                        //mInfoTextView.setText(R.string.result_human_wins);
                        String defaultMessage = getResources().getString(R.string.result_human_wins);
                        mInfoTextView.setText(mPrefs.getString("victory_message", defaultMessage));
                        mGameOver = true;
                        humanWinsCount++;
                        mHumanCount.setText(String.valueOf(humanWinsCount));
                        humanFirst = !humanFirst;
                        break;
                    default:
                        mInfoTextView.setText(R.string.result_computer_wins);
                        mGameOver = true;
                        androidWinsCount++;
                        mAndroidCount.setText(String.valueOf(androidWinsCount));
                        humanFirst = !humanFirst;
                        break;
                }
            }

            // So we aren't notified of continued events when finger is moved
            return false;
        }
    };
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_CANCELED) {
            // Apply potentially new settings

            mSoundOn = mPrefs.getBoolean("sound", true);

            String difficultyLevel = mPrefs.getString("difficulty_level",
                    getResources().getString(R.string.difficulty_harder));

            if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy)))
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
            else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder)))
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
            else
                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
        }
    }
}
