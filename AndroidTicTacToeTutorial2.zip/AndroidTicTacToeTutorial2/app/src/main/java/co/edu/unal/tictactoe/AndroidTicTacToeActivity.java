package co.edu.unal.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Skeleton of an Android Things activity.
 * <p>
 * Android Things peripheral APIs are accessible through the PeripheralManager
 * For example, the snippet below will open a GPIO pin and set it to HIGH:
 * <p>
 * PeripheralManager manager = PeripheralManager.getInstance();
 * try {
 * Gpio gpio = manager.openGpio("BCM6");
 * gpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * gpio.setValue(true);
 * } catch (IOException e) {
 * Log.e(TAG, "Unable to access GPIO");
 * }
 * <p>
 * You can find additional examples on GitHub: https://github.com/androidthings
 */
public class AndroidTicTacToeActivity extends AppCompatActivity {
    // Represents the internal state of the game
    private TicTacToeGame mGame;
    // Buttons making up the board
    private Button mBoardButtons[];

    // Various text displayed
    private TextView mInfoTextView;
    private TextView mHumanCount;
    private TextView mTieCount;
    private TextView mAndroidCount;


    private boolean mGameOver;

    private boolean humanFirst;
    private int humanWinsCount;
    private int tiesCount;
    private int androidWinsCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_tac_toe);

        mBoardButtons = new Button[TicTacToeGame.BOARD_SIZE];
        mBoardButtons[0] = (Button) findViewById(R.id.one);
        mBoardButtons[1] = (Button) findViewById(R.id.two);
        mBoardButtons[2] = (Button) findViewById(R.id.three);
        mBoardButtons[3] = (Button) findViewById(R.id.four);
        mBoardButtons[4] = (Button) findViewById(R.id.five);
        mBoardButtons[5] = (Button) findViewById(R.id.six);
        mBoardButtons[6] = (Button) findViewById(R.id.seven);
        mBoardButtons[7] = (Button) findViewById(R.id.eight);
        mBoardButtons[8] = (Button) findViewById(R.id.nine);

        mInfoTextView = (TextView) findViewById(R.id.information);
        mHumanCount = (TextView) findViewById(R.id.humanCount);
        mTieCount = (TextView) findViewById(R.id.tieCount);
        mAndroidCount = (TextView) findViewById(R.id.androidCount);

        mGame = new TicTacToeGame();
        humanFirst = true;
        humanWinsCount = 0;
        tiesCount = 0;
        androidWinsCount = 0;


        startNewGame();

    }


    // Set up the game board.
    private void startNewGame() {
        mGameOver = false;
        mGame.clearBoard();
        // Reset all buttons
        for (int i = 0; i < mBoardButtons.length; i++) {
            mBoardButtons[i].setText("");
            mBoardButtons[i].setEnabled(true);
            mBoardButtons[i].setOnClickListener(new ButtonClickListener(i));
        }
        // Human goes first

        if(humanFirst)
            mInfoTextView.setText(R.string.first_human);
        else {
            mInfoTextView.setText(R.string.first_computer);
            computerTurn();
        }
    }

    private int computerTurn(){
        int move = mGame.getComputerMove();
        setMove(move, TicTacToeGame.COMPUTER_PLAYER);
        return mGame.checkForWinner();
    }

    // Handles clicks on the game board buttons
    private class ButtonClickListener implements View.OnClickListener {
        int location;

        public ButtonClickListener(int location) {
            this.location = location;
        }

        public void onClick(View view) {
            if (mGameOver || !mBoardButtons[location].isEnabled())
                return;
            setMove(location, TicTacToeGame.HUMAN_PLAYER);

            // If no winner yet, let the computer make a move
            int winner = mGame.checkForWinner();
            if (winner == 0) {
                mInfoTextView.setText(R.string.turn_computer);
                winner = computerTurn();
            }

            if (winner == 0)
                mInfoTextView.setText(R.string.turn_human);
            else if (winner == 1) {
                mInfoTextView.setText(R.string.result_tie);
                mGameOver = true;
                tiesCount++;
                mTieCount.setText(String.valueOf(tiesCount));
            } else if (winner == 2) {
                mInfoTextView.setText(R.string.result_human_wins);
                mGameOver = true;
                humanWinsCount++;
                mHumanCount.setText(String.valueOf(humanWinsCount));
            } else {
                mInfoTextView.setText(R.string.result_computer_wins);
                mGameOver = true;
                androidWinsCount++;
                mAndroidCount.setText(String.valueOf(androidWinsCount));
            }
        }
    }
    private void setMove(int location, char player) {

        mGame.setMove(location, player);
        mBoardButtons[location].setEnabled(false);
        mBoardButtons[location].setText(String.valueOf(player));
        if (player == TicTacToeGame.HUMAN_PLAYER)
            mBoardButtons[location].setTextColor(Color.rgb(0, 200, 0));
        else
            mBoardButtons[location].setTextColor(Color.rgb(200, 0, 0));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add("New Game");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        startNewGame();
        return true;
    }
}
