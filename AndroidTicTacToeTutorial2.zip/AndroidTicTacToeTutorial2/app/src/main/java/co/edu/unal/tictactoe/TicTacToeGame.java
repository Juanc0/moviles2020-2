package co.edu.unal.tictactoe;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;


public class TicTacToeGame {

    private char mBoard[] = {'1','2','3','4','5','6','7','8','9'};
    public static final int BOARD_SIZE = 9;

    public static final char OPEN_SPOT = ' ';
    public static final char HUMAN_PLAYER = 'X';
    public static final char COMPUTER_PLAYER = 'O';

    private Random mRand;

    public TicTacToeGame() {

        // Seed the random number generator
        mRand = new Random();

        char turn = HUMAN_PLAYER;    // Human starts first
        int  win = 0;                // Set to 1, 2, or 3 when game is over

        // Keep looping until someone wins or a tie
        while (win == 0)
        {
            if (turn == HUMAN_PLAYER){
                //getUserMove();
                turn = COMPUTER_PLAYER;
            } else {
                getComputerMove();
                turn = HUMAN_PLAYER;
            }

            win = checkForWinner();
        }

        // Report the winner
        System.out.println();
        if (win == 1)
            System.out.println("It's a tie.");
        else if (win == 2)
            System.out.println(HUMAN_PLAYER + " wins!");
        else if (win == 3)
            System.out.println(COMPUTER_PLAYER + " wins!");
        else
            System.out.println("There is a logic problem!");
    }


    /** Clear the board of all X's and O's by setting all spots to OPEN_SPOT. */
    public void clearBoard(){
        for (int i = 0; i < BOARD_SIZE; i++)
            mBoard[i] = OPEN_SPOT;
    }

    /** Set the given player at the given location on the game board.
     *  The location must be available, or the board will not be changed.
     *
     * @param player - The HUMAN_PLAYER or COMPUTER_PLAYER
     * @param location - The location (0-8) to place the move
     */
    public void setMove(int location, char player){
        if (location <= 8 && location >=0 && mBoard[location] == OPEN_SPOT)
            mBoard[location] = player;
    }



    /** Return the best move for the computer to make. You must call setMove()
     * to actually make the computer move to that location.
     * @return The best move for the computer to make (0-8).
     */
    public int getComputerMove(){
        char[] board = new char[BOARD_SIZE];
        for (int i = 0; i < BOARD_SIZE; i++)
            board[i] = mBoard[i];

        int move;
        char curr;

        // First see if there's a move O can make to win
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (board[i] == OPEN_SPOT) {
                curr = board[i];
                board[i] = COMPUTER_PLAYER;
                if (checkWinner(board, COMPUTER_PLAYER))
                    return i;
                else
                    board[i] = curr;
            }
        }

        // See if there's a move O can make to block X from winning
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (board[i] == OPEN_SPOT) {
                curr = board[i];   // Save the current number
                board[i] = HUMAN_PLAYER;
                if (checkWinner(board, HUMAN_PLAYER))
                    return i;
                else
                    board[i] = curr;
            }
        }

        // Generate random move
        do{
            move = mRand.nextInt(BOARD_SIZE);
        } while (board[move] != OPEN_SPOT);

        return move;
    }


    private boolean checkWinner(char[] board, char player) {
        // Check horizontal wins
        for (int i = 0; i <= 6; i += 3)
            if (board[i] == player &&
                    board[i+1] == player &&
                    board[i+2]== player)
                return true;

        // Check vertical wins
        for (int i = 0; i <= 2; i++)
            if (board[i] == player &&
                    board[i+3] == player &&
                    board[i+6]== player)
                return true;

        // Check for diagonal wins
        if ((board[0] == player &&
                board[4] == player &&
                board[8] == player) ||
                (board[2] == player &&
                        board[4] == player &&
                        board[6] == player))
            return true;

        return false;
    }

    /**
     * Check for a winner and return a status value indicating who has won.
     * @return Return 0 if no winner or tie yet, 1 if it's a tie, 2 if X won,
     * or 3 if O won.
     */
    public int checkForWinner(){
        if(checkWinner(mBoard, HUMAN_PLAYER))
            return 2;
        if(checkWinner(mBoard, COMPUTER_PLAYER))
            return 3;

        // Check for tie
        for (int i = 0; i < BOARD_SIZE; i++) {
            // If we find a number, then no one has won yet
            if (mBoard[i] == OPEN_SPOT)
                return 0;
        }
        // If we make it through the previous loop, all places are taken, so it's a tie
        return 1;
    }

}
